<?php 
	session_start();
	require_once "./mvc/Bridge.php";

	$myApp = new App();

 ?>